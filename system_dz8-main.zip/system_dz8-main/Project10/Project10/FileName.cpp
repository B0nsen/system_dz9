#include <windows.h>
#include <tchar.h>
#include "resource.h"
#include "stdafx.h"

BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wp, LPARAM lp);

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPTSTR lpszCmdLine, int nCmdShow)
{
	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DlgProc);
}

BOOL CALLBACK DlgProc(HWND hWnd, UINT message, WPARAM wp, LPARAM lp)
{
	static HWND hButton1, hButton2, hButton3, hButton4, hEdit1, hList1, hList2;
	static HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

	static PROCESSENTRY32 pe32;
	static _TCHAR str[100];
	switch (message)
	{

	case WM_CLOSE:
	{
		EndDialog(hWnd, 0);
		return TRUE;
		break;
	}

	case WM_INITDIALOG:
	{
		hButton1 = GetDlgItem(hWnd, IDC_BUTTON1);
		hButton2 = GetDlgItem(hWnd, IDC_BUTTON2);
		hButton3 = GetDlgItem(hWnd, IDC_BUTTON3);
		hButton4 = GetDlgItem(hWnd, IDC_BUTTON4);
		hEdit1 = GetDlgItem(hWnd, IDC_EDIT1);
		hList1 = GetDlgItem(hWnd, IDC_LIST1);
		hList2 = GetDlgItem(hWnd, IDC_LIST2);
		memset(&pe32, 0, sizeof(PROCESSENTRY32));
		pe32.dwSize = sizeof(PROCESSENTRY32);
		return TRUE;
	}


	case WM_COMMAND:
	{
		if (LOWORD(wp) == IDC_BUTTON1)
		{
			int index = SendMessage(hList1, LB_GETCOUNT, 0, 0);
			for (int i = 0; i < index; i++)
			{
				SendMessage(hList1, LB_DELETESTRING, 0, 0);
			}
			if (Process32First(snapshot, &pe32))
			{
				wsprintf(str, TEXT("%s\0"), pe32.szExeFile);
				SendMessage(hList1, LB_ADDSTRING, 0, (LPARAM)str);
				while (Process32Next(snapshot, &pe32))
				{
					wsprintf(str, TEXT("%s\0"), pe32.szExeFile);
					SendMessage(hList1, LB_ADDSTRING, 0, (LPARAM)str);
				}
			}
		}
		if (LOWORD(wp) == IDC_BUTTON2)
		{
			int index = SendMessage(hList1, LB_GETCURSEL, 0, 0);
			_TCHAR FileName1[50];
			SendMessage(hList1, LB_GETTEXT, index, (LPARAM)FileName1);
			if (Process32First(snapshot, &pe32))
			{
				if (wcscmp(FileName1, pe32.szExeFile))
				{
					while (Process32Next(snapshot, &pe32))
					{
						if (!wcscmp(FileName1, pe32.szExeFile))
						{
							break;
						}
					}
				}

			}
			HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pe32.th32ProcessID);
			TerminateProcess(hProcess, 0);
			
		}
		if (LOWORD(wp) == IDC_BUTTON4)
		{
			GetWindowText(hEdit1, str, 100);
			STARTUPINFO s = {sizeof(STARTUPINFO)};
			PROCESS_INFORMATION p;
			BOOL cp = CreateProcess(NULL, str, NULL, NULL, FALSE, 0, NULL, NULL, &s, &p);
			if (cp)
			{
				CloseHandle(p.hThread);
				CloseHandle(p.hProcess);
			}
		}
		if (LOWORD(wp) == IDC_BUTTON3)
		{
			int index = SendMessage(hList1, LB_GETCURSEL, 0, 0);
			_TCHAR FileName1[50];
			SendMessage(hList1, LB_GETTEXT, index, (LPARAM)FileName1);
			
			if (Process32First(snapshot, &pe32))
			{
				if (wcscmp(FileName1, pe32.szExeFile))
				{
					while (Process32Next(snapshot, &pe32))
					{
						if (!wcscmp(FileName1, pe32.szExeFile))
						{
							break;
						}
					}
				}
				
			}
			wsprintf(str, TEXT("ID:  %4u  Threads: %5u   priority:  %2u    name:   %s\0"), pe32.th32ProcessID, pe32.cntThreads, pe32.pcPriClassBase, pe32.szExeFile);
			SendMessage(hList2, LB_DELETESTRING, 0, 0);
			SendMessage(hList2, LB_ADDSTRING, 0, (LPARAM)str);
		}
		return TRUE;
		}
	}
	return FALSE;
}